#!/bin/bash
#prepare hosts file to be copied to all the nodes
LOGFILE=/tmp/masterinstall.log
exec  > $LOGFILE 2>&1

declare -a ipaddress 
IFS=', ' read -r -a ipaddress <<< `cat /tmp/test.txt`
declare -a myhostnames
IFS=', ' read -r -a myhostnames <<< `cat /tmp/test1.txt`

#add master ip to ipaddress array
masterip=`cat /tmp/masterip.txt`
ipaddress=("${ipaddress[@]}" "${masterip}")
mastername=`hostname -s` 
myhostnames=("${myhostnames[@]}" "${mastername}")
domain=`cat /tmp/domain.txt`

#initialize hosts
echo "127.0.0.1   localhost localhost.localdomain" >/tmp/hosts

#prepare hosts file
alen=${#ipaddress[@]}
for (( i=0; i < ${alen}; i++ ));
do
  # check hostname resolution
  myname=`nslookup ${ipaddress[$i]}|grep name|cut -d= -f2|tr -d ' \t\n\r\f'`
  if  [ $? ]; then
    shortname=`echo $myname|cut -f1 -d.`
    echo ${ipaddress[$i]} ${myname: : -1} $shortname >> /tmp/hosts 
  else 
    echo ${ipaddress[$i]} ${myhostnames[$i]}.${domain}  ${myhostnames[$i]} >> /tmp/hosts
  fi
done

#prepare ICp hosts file
echo "[master]" > /tmp/icphosts
echo ${ipaddress[${alen}-1]} >> /tmp/icphosts
echo "" >> /tmp/icphosts
echo "[proxy]" >> /tmp/icphosts
echo  ${ipaddress[${alen}-2]} >> /tmp/icphosts 
echo "" >> /tmp/icphosts
echo "[worker]" >> /tmp/icphosts
for (( i=0; i < ${alen}-2; i++ ));
do
  echo  ${ipaddress[$i]}  >> /tmp/icphosts
done

#chmod for private key
chmod 0600 /tmp/icpsshkey

#Install prereqs on all nodes
for (( i=0; i < ${alen}-1; i++ ));
do
 echo ${ipaddress[$i]}
 nodename=`cat /tmp/hosts|grep  ${ipaddress[$i]}|cut -f2 -d" "`
 echo $nodename
 scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i /tmp/icpsshkey /tmp/icpinst.zip  ${ipaddress[$i]}:/tmp
 scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i /tmp/icpsshkey /tmp/hosts  ${ipaddress[$i]}:/tmp
 echo "Installing prereqs on node $ipaddress $nodename ..."
 ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i  /tmp/icpsshkey ${ipaddress[$i]} "cd /tmp; mkdir icpinstall; cd icpinstall; unzip -q ../icpinst.zip; chmod 755 *; ./disk-part.sh; ./prereqs.sh $nodename; mv /etc/hosts /etc/hosts.orig; cp /tmp/hosts /etc/" 
done

#Increase FS with added disk on master
/tmp/icpinstall/disk-part.sh

#Update /etc/hosts
mv /etc/hosts /etc/hosts.orig
cp /tmp/hosts /etc

#Run prereqs on master
masterhname=`cat /tmp/hosts|grep  ${ipaddress[$alen-1]}|cut -f2 -d" "`
echo $masterhname
/tmp/icpinstall/prereqs.sh $masterhname

#Expand ICp installer
cd /tmp
tar zxf ibm-cloud-private-installer-1.2.0.tar.gz
mv ibm-cloud-private-1.2.0 /opt/
cd /opt/ibm-cloud-private-1.2.0
mv /tmp/ibm-cloud-private-x86_64-1.2.0.tar.gz images/

#Prepare hosts and key
cp /tmp/icphosts /opt/ibm-cloud-private-1.2.0/hosts
cp /tmp/icpsshkey /opt/ibm-cloud-private-1.2.0/ssh_key

#Run the installer
tar xf images/ibm-cloud-private-x86_64-1.2.0.tar.gz -C images
docker load -i images/ibm-cloud-private-x86_64-1.2.0.tar
timeout 2000 docker run -e LICENSE=accept --net=host --rm -t -v "$(pwd)":/installer/cluster ibmcom/cfc-installer:1.2.0-ee install 

echo "Installation Complete"
exit 0
