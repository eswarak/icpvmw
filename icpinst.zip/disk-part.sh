#!/bin/bash
#check the disk if it has partitions
for i in `lsblk|grep disk|grep sd|awk '{print $1}'`
 do
  echo "disk is $i"
  /sbin/sfdisk -d /dev/$i 2>&1
  if [ !$? ]; then
    echo "Device not partitioned"
    echo -e "o\nn\np\n1\n\n\nw" | fdisk /dev/$i
    pvcreate /dev/${i}1
    vgextend  `vgdisplay|grep VG\ Name|awk '{print $3}'` /dev/${i}1
    lvextend -l +100%FREE `lvdisplay|grep LV\ Path|grep -v swap|awk '{print $3}'` -r
  fi
 done
echo "Disk addition to lvm complete"
exit 0
